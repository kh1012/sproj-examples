# Create Alignment

![](https://assets.entrepreneur.com/content/3x2/2000/1662794323-Untitleddesign-2022-09-10T111821740.png?format=pjeg&auto=webp&crop=16:9&width=675&height=380)

입력한 값으로 선을 그릴 수 있습니다.