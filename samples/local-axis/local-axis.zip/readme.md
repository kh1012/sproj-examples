# Local Axis

![](https://qph.cf2.quoracdn.net/main-qimg-3d0ae7fb37b4fe80f2a066cfe99f104c)

제품으로부터 좌표 정보를 불러옵니다.
<br>
불러온 좌표 정보에 Local Axis를 부여 합니다.